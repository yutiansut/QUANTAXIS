# coding:utf-8

from QUANTAXIS.QAARP import QA_Account, QA_Portfolio, QA_User, QA_Risk, QA_Performance


class QAAnalyasis_Account():
    def __init__(self, account):
        self.account = account

    def rank(self):
        pass
