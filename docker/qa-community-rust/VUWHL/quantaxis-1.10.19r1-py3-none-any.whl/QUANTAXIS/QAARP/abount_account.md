# QAACCOUNT


ACCOUNT 

```
# 内部维护表
- asset/cash/hold/history/detail
# 临时变量
- cash_available/sell_available
# 惰性计算变量
- latest_assets/latest_cash

# 随市场改变的变量
- current_time

# 为了较好打印的
- hold_table/assets_series

```


